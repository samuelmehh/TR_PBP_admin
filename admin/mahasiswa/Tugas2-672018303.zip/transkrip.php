<?php require_once "components/header.php"; ?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Transkrip Page</h1>
</div>

<div class="container">
	<div class="table-responsive">
		<table class="table table-bordered">
			<tr>
				<td></td>
				<td class="text-center">SKS</td>
				<td class="text-center">AK</td>
			</tr>
			<tr>
				<td>Total</td>
				<td class="text-center"><strong>78</strong></td>
				<td class="text-center"><strong>283</strong></td>
			</tr>
			<tr>
				<td>IPK</td>
				<td class="text-center"><strong><?= $_SESSION['data']['ipk'] ?></strong></td>
				<td></td>
			</tr>
		</table>
	</div>
</div>

<?php require_once "components/footer.php"; ?>