<?php
	
	$user = array();//tabel user
	$user['672020001'] = 'rahasia';
	$user['672020002'] = 'susahditebak';
	$user['672020003'] = 'lupadeh123';
	$user['672018303'] = 'amanda123';

	$data = array();//tabel mahasiswa
	$data['672020001']['nama'] = 'Ayu Lestari';
	$data['672020001']['ipk'] = 3.77;
	$data['672020001']['asal'] = 'Tegal';
	
	$data['672020002']['nama'] = 'Eka Sap';
	$data['672020002']['ipk'] = 3.96;
	$data['672020002']['asal'] = 'Semarang';
	
	$data['672020003']['nama'] = 'Indra Jay';
	$data['672020003']['ipk'] = 3.58;
	$data['672020003']['asal'] = 'Pekalongan';

	$data['672018303']['nama'] = 'Amanda Calvina Izumi';
	$data['672018303']['ipk'] = 3.63;
	$data['672018303']['asal'] = 'Salatiga';

?>