<script type="text/javascript" src="assets/jquery-3.5.1/jquery-3.5.1.slim.min.js"></script>
<script type="text/javascript" src="assets/bootstrap-4.5.3/js/bootstrap.min.js"></script>
</body>
</html>